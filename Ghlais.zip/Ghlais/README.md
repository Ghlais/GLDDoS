<div align=center>
 
# 🚀 GhlaisDev: Release v1.5 - Free DDoS Panel 🚀

# Store: https://condi.billgang.store/

<p>
 <img src="https://img.shields.io/github/stars/hoaan1995/GhlaisDev?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/hoaan1995/GhlaisDev?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/hoaan1995/GhlaisDev?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>

> Terminal only accepts ANSI color.<br>
> Username: admin<br>
> Password: admin<br>
<p align="center">  <a href="https://t.me/learneverything9"><img width="160" height="50" src="https://i.imgur.com/N7AK7XY.png"></a></p>
 
## Language</br>

 <img src="https://img.shields.io/badge/Python-FFDD00?style=for-the-badge&logo=python&logoColor=blue"/> <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/> <img src="https://img.shields.io/badge/Perl-39457E?style=for-the-badge&logo=perl&logoColor=white"/> <img src="https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white"/> <img src="https://img.shields.io/badge/Go-00ADD8?style=for-the-badge&logo=go&logoColor=white"/>
 </div>
 
 ## Logs</br>
 - UPDATE TLS AND HTTP1 METHODS!
 - UPDATE NEW HTTP(s) PROXY!
 
## Screenshot
![lk](https://i.ibb.co/LNkqyPR/bandicam-2022-04-12-22-11-34-101.jpg)

# Tree
* [Read now pls](#README)
* [Info](#Info)
* [Setup](#Setup)
* [Credits](#Credits)
* [T.O.S](#TOS)
* [Contact](#Contact)

# README ♥️
Thank you for using, please help me press a star button, thank you very much.<br>
One star = continuously updating multiple methods

# Info
- [x] Open Source
- [x] Powerful
- [x] Simple
- [x] Methods for Layer 4 and 7
- [x] Bypass (Cloudflare, OVH, NFO,...)  


# Setup
```sh
Debain, Ubuntu (Ubuntu 20.04 better):
sudo apt-get install git -y
sudo apt-get install golang -y
sudo apt-get install perl -y
sudo apt-get install python3 -y
sudo apt-get install python2 -y
sudo apt-get install python3-pip -y
curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -;sudo apt -y install nodejs

How to use: 
- Recommended in shell of google, azure,...
- Using vps with high speed will be stronger

git clone https://github.com/hoaan1995/GhlaisDev/
cd GhlaisDev/
npm i requests https-proxy-agent crypto-random-string events fs net cloudscraper request hcaptcha-solver randomstring cluster cloudflare-bypasser http http2 crypto tls
pip3 install -r requirements.txt
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt-get install ./google-chrome-stable_current_amd64.deb
ulimit -n 999999
chmod 777 *
python3 c2.py
```

# Credits
```sh
zxcr9999 (Reworked CnC and added some methods .-.)
SkyWtkhIsBack (Example Panel and L7 methods <3)
Empfaked (Layer 7 methods <3)
HyukIsBack (Layer 7 methods <3)
im-federal (Layer 4 and AMP methods <3)
R00tS3C (Layer 4 and AMP methods <3)
forkyyy (LAYER 7 METHODS <3)
Leeon123 (SPECIAL METHODS <3)
TheSpeedX (HTTP, SOCKS5, SOCK4 proxies <3)
```

# TOS:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```

# CONTACT:
```sh
Telegram: @zxcr9999
Discord: zxcr9999#1770
```
